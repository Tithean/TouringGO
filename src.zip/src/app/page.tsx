import Search from "@/components/Search";

export default function HomePage() {
  return (
    <main className="min-h-screen p-6">
      <Search />
    </main>
  );
}
