"use client";

import { useEffect, useState } from "react";
import type { Attraction, SearchApiResponse } from "@/services/attractionType";
import SearchResultCard from "./SearchResultpage";

export default function SearchResult({ keyword }: { keyword: string }) {
  const [attractions, setAttractions] = useState<Attraction[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    async function fetchAttractions() {
      if (!keyword.trim()) {
        setAttractions([]);
        setError("");
        return;
      }

      try {
        setLoading(true);
        setError("");

        const params = new URLSearchParams({
          keyword: keyword.trim(),
          page: "0",
          size: "20",
        });

        const response = await fetch(`/api/attractions/search?${params.toString()}`);

        if (!response.ok) {
          throw new Error(`API error ${response.status}`);
        }

        const data: SearchApiResponse = await response.json();
        setAttractions(data.content || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load attractions");
        setAttractions([]);
      } finally {
        setLoading(false);
      }
    }

    fetchAttractions();
  }, [keyword]);

  if (!keyword) return null;
  if (loading) return <div className="py-8 text-center text-gray-500">Searching...</div>;
  if (error) return <div className="py-8 text-center text-red-500">{error}</div>;
  if (attractions.length === 0) {
    return <div className="py-8 text-center text-gray-500">No attractions found for "{keyword}"</div>;
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 p-4">
      {attractions.map((item) => (
        <SearchResultCard key={item.id} item={item} />
      ))}
    </div>
  );
}