"use client"
import { useState } from "react";

// Types matching your API response
export interface Province {
  id: number;
  nameKh: string;
  nameEn: string;
  region: string;
  imageUrl: string;
}

export interface Attraction {
  id: number;
  province: Province;
  nameKh: string;
  nameEn: string;
  descriptionEn: string | null;
  category: string;
  rating: number;
  imageUrls: string[];
}

export interface SearchApiResponse {
  content: Attraction[];
  page: number;
  size: number;
  totalPages: number;
  totalElements: number;
}

export default function SearchComponent() {
  const [keyword, setKeyword] = useState("");
  const [attractions, setAttractions] = useState<Attraction[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!keyword.trim()) return;
    setLoading(true);

    try {
      const response = await fetch(
        `https://cam-trip.cheat.casa/api/attractions/search?keyword=${encodeURIComponent(
          keyword
        )}&page=0&size=20`
      );
      const data: SearchApiResponse = await response.json();

      // Access the inner 'content' array
      setAttractions(data.content || []);
    } catch (error) {
      console.error("Failed to fetch search results:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Search Input Controls */}
      <div className="flex gap-2 mb-6">
        <input
          type="text"
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          placeholder="ស្វែងរកទីកន្លែង..."
          className="border p-2 rounded flex-1"
        />
        <button
          onClick={handleSearch}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          {loading ? "Searching..." : "Search"}
        </button>
      </div>

      {/* Render Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {attractions.map((item) => (
          <div
            key={item.id}
            className="border rounded-lg overflow-hidden shadow-sm hover:shadow-md transition"
          >
            {/* Display Province image or fallback */}
            <img
              src={
                item.imageUrls?.[0] ||
                item.province?.imageUrl ||
                "https://via.placeholder.com/300x200"
              }
              alt={item.nameEn}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <span className="text-xs font-semibold bg-blue-100 text-blue-800 px-2 py-1 rounded">
                {item.category}
              </span>
              <h3 className="font-bold text-lg mt-2">{item.nameKh}</h3>
              <p className="text-sm text-gray-600">{item.nameEn}</p>
              <div className="mt-3 flex justify-between items-center text-sm">
                <span className="text-gray-500">{item.province?.nameEn}</span>
                <span className="text-yellow-500 font-semibold">
                  ⭐ {item.rating}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}